#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "election.h"
#include <gtk/gtk.h>
enum{
	EID,
	ENOM,
	ENBR_HABITANT,
	EADRESSE,
	ECODE_POSTAL,
	EMUNICIPALITE,
	ENBR_VOTE,
	ENBR_CONSEILLEE,
	EJOUR,
	EMOIS,
	EANNEE,
	COLUMNS
};

int id_rand(){
	int id;
	
	srand(time(NULL));
	id=rand()%10000;
			
		return id;}
void ajouter_election(Election p)
{


	int i;
	char iden[40];
	
	FILE *f;
	f=fopen("election.txt","a+");
	if(f!=NULL)
	{
fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s\n",p.id,p.nom,p.nbr_habitant,p.adresse,p.code_postal,p.municipalite,p.nbr_vote,p.nbr_conseillee,p.d.jour,p.d.mois,p.d.annee);
		fclose(f);
}
}
void afficher_election(GtkWidget *liste)
{
	GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char id[20];
	char nom[10];
	char nbr_habitant[10];
	char adresse[10];
	char code_postal[10];
	char municipalite[10];
	char nbr_vote[10];
	char nbr_conseillee[10];
	char jour[20];
	char mois[20];
	char annee[20];
	store=NULL;
	FILE *f;

	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column=gtk_tree_view_column_new_with_attributes(" id",renderer,"text",EID,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",ENOM,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" Nombre d'habitant",renderer,"text",ENBR_HABITANT,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" Adresse",renderer,"text",EADRESSE,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" Code Postal",renderer,"text",ECODE_POSTAL,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" Municipalite",renderer,"text",EMUNICIPALITE,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" Nombre bdv",renderer,"text",ENBR_VOTE,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" Nombre conseillee",renderer,"text",ENBR_CONSEILLEE,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" jour",renderer,"text",EJOUR,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" mois",renderer,"text",EMOIS,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" Année",renderer,"text",EANNEE,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);


	}

	store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("election.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{ f = fopen("election.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s\n",id,nom,nbr_habitant,adresse,code_postal,municipalite,nbr_vote,nbr_conseillee,jour,mois,annee)!=EOF)

	{

		gtk_list_store_append (store, &iter);
gtk_list_store_set(store,&iter,EID,id,ENOM,nom,ENBR_HABITANT,nbr_habitant,EADRESSE,adresse,ECODE_POSTAL,code_postal,EMUNICIPALITE,municipalite,ENBR_VOTE,nbr_vote,ENBR_CONSEILLEE,nbr_conseillee,EJOUR,jour,EMOIS,mois,EANNEE,annee,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
	}
}
/*void supprimer_election(Election p)
    {   Election p2;
	FILE *f, *g;
	f=fopen("election.txt","r");
	g=fopen("election2.txt","w");
	if(f==NULL || g==NULL)
	  { return;
	  }
	else
	{ while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s\n",p2.id,p2.nom,p2.nbr_habitant,p2.adresse,p2.code_postal,p2.municipalite,p2.nbr_vote,p2.nbr_conseillee,p2.d.jour,p2.d.mois,p2.d.annee)!=EOF)
	   {
if( strcmp(p.id,p2.id)!=0 || strcmp(p.nom,p2.nom)!=0 || strcmp(p.nbr_habitant,p2.nbr_habitant)!=0  ||strcmp(p.adresse,p2.adresse) ||strcmp(p.code_postal,p2.code_postal)!=0 || strcmp(p.municipalite,p2.municipalite) || strcmp(p.nbr_vote,p2.nbr_vote) || strcmp(p.nbr_conseillee,p2.nbr_conseillee))
fprintf(g,"%s %s %s %s %s %s %s %s %s %s %s\n",p2.id,p2.nom,p2.nbr_habitant,p2.adresse,p2.code_postal,p2.municipalite,p2.nbr_vote,p2.nbr_conseillee,p2.d.jour,p2.d.mois,p2.d.annee); 
	}   
fclose(f);
fclose(g);
remove("election.txt");
rename("election2.txt","election.txt");
	}
    }*/
int modifier(char id[], Election nouv)
{
    int tr=0;
    Election p;
    FILE * f=fopen("election.txt", "r");
    FILE * f2=fopen("nouv.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s\n",p.id,p.nom,p.nbr_habitant,p.adresse,p.code_postal,p.municipalite,p.nbr_vote,p.nbr_conseillee,p.d.jour,p.d.mois,p.d.annee)
!=EOF)
        {
            if(strcmp( p.id , id )==0)
            {
                fprintf(f2,"%s %s %s %s %s %s %s %s %s %s %s\n",nouv.id,nouv.nom,nouv.nbr_habitant,nouv.adresse,nouv.code_postal,nouv.municipalite,nouv.nbr_vote,nouv.nbr_conseillee,nouv.d.jour,nouv.d.mois,nouv.d.annee);
                tr=1;
            }
            else
                fprintf(f2,"%s %s %s %s %s %s %s %s %s %s %s\n",p.id,p.nom,p.nbr_habitant,p.adresse,p.code_postal,p.municipalite,p.nbr_vote,p.nbr_conseillee,p.d.jour,p.d.mois,p.d.annee);


        }
    }
    fclose(f);
    fclose(f2);
    remove("election.txt");
    rename("nouv.txt", "election.txt");
    return tr;

}
int supprimer_election(char id[20])
{
    int tr=0;
    Election p;
    FILE * f=fopen("election.txt", "r");
    FILE * f2=fopen("nouv.txt", "w");
    if(f!=NULL && f2!=NULL)
    {
        while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s\n",p.id,p.nom,p.nbr_habitant,p.adresse,p.code_postal,p.municipalite,p.nbr_vote,p.nbr_conseillee,p.d.jour,p.d.mois,p.d.annee)
!=EOF)
        {
         if(strcmp( p.id , id)==0)
                tr=1;
            else
                fprintf(f2,"%s %s %s %s %s %s %s %s %s %s %s\n",p.id,p.nom,p.nbr_habitant,p.adresse,p.code_postal,p.municipalite,p.nbr_vote,p.nbr_conseillee,p.d.jour,p.d.mois,p.d.annee);

        }
    }
    fclose(f);
    fclose(f2);
    remove("election.txt");
    rename("nouv.txt", "election.txt");
    return tr;
}
Election chercher_election(char id[])
{
    Election p;
    int tr=0;
    FILE * f=fopen("election.txt", "r");
    if(f!=NULL)
    {
        while(tr==0&& fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s\n",p.id,p.nom,p.nbr_habitant,p.adresse,p.code_postal,p.municipalite,p.nbr_vote,p.nbr_conseillee,p.d.jour,p.d.mois,p.d.annee)!=EOF)
        {
          if(strcmp( p.id , id )==0)
                tr=1;
        }
    }
    fclose(f);
    if(tr==0)
        strcpy(p.id,"-1");
    return p;

}
Election afficher_chercher(GtkWidget *liste,char ID[]){
GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
	
	char id[20];
	char nom[10];
	char nbr_habitant[10];
	char adresse[10];
	char code_postal[10];
	char municipalite[10];
	char nbr_vote[10];
	char nbr_conseillee[10];
	char jour[20];
	char mois[20];
	char annee[20];
	Election E;
	Election p;
	store=NULL;
	FILE *f;

	store=gtk_tree_view_get_model(liste);
	if(store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column=gtk_tree_view_column_new_with_attributes(" id",renderer,"text",EID,NULL);
		gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
		
		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" nom",renderer,"text",ENOM,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" Nombre d'habitant",renderer,"text",ENBR_HABITANT,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" Adresse",renderer,"text",EADRESSE,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" Code Postal",renderer,"text",ECODE_POSTAL,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" Municipalite",renderer,"text",EMUNICIPALITE,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" Nombre bdv",renderer,"text",ENBR_VOTE,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

		renderer = gtk_cell_renderer_text_new ();
                column = gtk_tree_view_column_new_with_attributes(" Nombre conseillee",renderer,"text",ENBR_CONSEILLEE,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

 		column = gtk_tree_view_column_new_with_attributes(" Jour",renderer,"text",EJOUR,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

  		column = gtk_tree_view_column_new_with_attributes(" Mois",renderer,"text",EMOIS,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);

  		column = gtk_tree_view_column_new_with_attributes(" Année",renderer,"text",EANNEE,NULL);
                gtk_tree_view_append_column (GTK_TREE_VIEW(liste),column);



	}

	store=gtk_list_store_new(COLUMNS, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);

	f=fopen("election.txt","r");
	if(f==NULL)
	{
		return;
	}
	else
	{ E=chercher_election(ID);
	
		gtk_list_store_append (store, &iter);
gtk_list_store_set(store,&iter,EID,E.id,ENOM,E.nom,ENBR_HABITANT,E.nbr_habitant,EADRESSE,E.adresse,ECODE_POSTAL,E.code_postal,EMUNICIPALITE,E.municipalite,ENBR_VOTE,E.nbr_vote,ENBR_CONSEILLEE,E.nbr_conseillee,-1);
	}
	fclose(f);
	gtk_tree_view_set_model(GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));
g_object_unref (store);
	}



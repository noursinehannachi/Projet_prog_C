#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "election.h"
#include<math.h>

confirmation[0]={};
void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data)
{

	Election p;
	char joure[20];
	char moise[20];
	char an[20];
	char iden[20];
	int a,b,c,d;
	int i;
	char di[20];
GtkWidget *input1, *input2,*input3,*input4,*input5,*input6,*input7,*combobox1,*alert,*day,*mois,*annee,*ide;
GtkWidget *ajouter;
	
	
ajouter=lookup_widget(objet,"ajouter_election");

input2=lookup_widget(objet,"nom");
input3=lookup_widget(objet,"adresse");
combobox1=lookup_widget(objet,"municipalite");
input4=lookup_widget(objet,"code_postal");
day=lookup_widget(objet,"jour");
mois=lookup_widget(objet,"mois");
annee=lookup_widget(objet,"annee");
input5=lookup_widget(objet,"nbr_vote");
input6=lookup_widget(objet,"nbr_conseillee");
input7=lookup_widget(objet,"nbr_habitant");
//strcpy(p.id,gtk_entry_get_text(GTK_ENTRY(input1)));

strcpy(p.nom,gtk_entry_get_text(GTK_ENTRY(input2)));

strcpy(p.adresse,gtk_entry_get_text(GTK_ENTRY(input3)));

strcpy(p.municipalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(combobox1)));
	
strcpy(p.code_postal,gtk_entry_get_text(GTK_ENTRY(input4)));

strcpy(p.nbr_vote,gtk_entry_get_text(GTK_ENTRY(input5)));

strcpy(p.nbr_conseillee,gtk_entry_get_text(GTK_ENTRY(input6)));

strcpy(p.nbr_habitant,gtk_entry_get_text(GTK_ENTRY(input7)));

a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(day));
	
b=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	
c=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	sprintf(joure,"%d",a);
	sprintf(moise,"%d",b);
	sprintf(an,"%d",c);
strcpy(p.d.jour,joure);
strcpy(p.d.mois,moise);
strcpy(p.d.annee,an);
d=id_rand();
sprintf(di,"%d",d);
strcpy(p.id,di);
input1=lookup_widget(objet,"id");

if (confirmation[0]==1){
gtk_label_set_text(GTK_LABEL(input1),p.id);
gtk_label_set_text(GTK_LABEL(alert),"Inscription terminée avec succée");
ajouter_election(p);
confirmation[0]=0;
}
else {gtk_label_set_text(GTK_LABEL(alert),"Inscription échoué");}


//input1=lookup_widget(objet,"id");

//gtk_label_set_text(GTK_LABEL(input1),p.id);
	
//gtk_widget_show (input1);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
	gchar* id;
	gchar* nom;
	gchar* adresse;
	gchar* nbr_habitant;
	gchar* code_postal;
	gchar* municipalite;
	gchar* nbr_vote;
	gchar* nbr_conseillee;
	gchar* jour;
	gchar* mois;
	gchar* annee;
	Election p;
	
	GtkTreeModel *model = gtk_tree_view_get_model(treeview);
	if (gtk_tree_model_get_iter(model, &iter, path))
	{
		gtk_tree_model_get (GTK_LIST_STORE(model), &iter, 0, &id, 1,&nom,2,&nbr_habitant,3,&adresse,4,&code_postal,5,&municipalite,6,&nbr_vote,7,&nbr_conseillee,8,&jour,9,&mois,10,&annee,11,-1);

	strcpy(p.id,id);
	strcpy(p.nom,nom);
	strcpy(p.nbr_habitant,nbr_habitant);
	strcpy(p.adresse,adresse);
	strcpy(p.code_postal,code_postal);
	strcpy(p.municipalite,municipalite);
	strcpy(p.nbr_vote,nbr_vote);
	strcpy(p.nbr_conseillee,nbr_conseillee);
	strcpy(p.d.jour,jour);
	strcpy(p.d.mois,mois);
	strcpy(p.d.annee,annee);
	remove(&id);
	//column=gtk_tree_view_get_column(treeview,gint n);
	//supprimer_election(p);
	afficher_election(treeview);


}
}



void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	
	GtkWidget *ajouter_election;
	GtkWidget *afficher;
	GtkWidget *treeview1;
	
	ajouter_election=lookup_widget(objet,"ajouter_election");
	gtk_widget_destroy(ajouter_election);
	
	afficher=create_afficher();
	
	gtk_widget_show(afficher);	
	treeview1=lookup_widget(afficher,"treeview1");
	

}


void
on_actualiser_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *w1, *afficher;
GtkWidget  *treeview1;

w1=lookup_widget(objet,"afficher");
afficher=create_afficher();
gtk_widget_show(afficher);
gtk_widget_hide(w1);
treeview1=lookup_widget(afficher,"treeview1");
afficher_election(treeview1);
}


void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *ajouter_election, *afficher;
afficher=lookup_widget(objet,"afficher");

gtk_widget_destroy(afficher);
ajouter_election=create_ajouter_election();
gtk_widget_show(ajouter_election);
}


void
on_chercher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
	GtkWidget *w1;
GtkWidget  *treeview1,*ID;
char IDE[20];
w1=lookup_widget(objet,"afficher");

treeview1=lookup_widget(objet,"treeview1");
ID=lookup_widget(objet,"chercher_afficher");
strcpy(IDE,gtk_entry_get_text(GTK_ENTRY(ID)));
afficher_chercher(treeview1,IDE);
	
}



void
on_confirmation_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if(gtk_toggle_button_get_active(togglebutton))
	{
		confirmation[0]=1;
	}
}


void
on_supprimer_election_clicked          (GtkWidget       *objet,
                                        gpointer         user_data)
{

char ID[20];
int S;
GtkWidget *alert_afficher,*id_supprimer,*supprimer;
GtkWidget *treeview;

supprimer=lookup_widget(objet,"afficher");
id_supprimer=lookup_widget(objet,"id_supp");
alert_afficher=lookup_widget(objet,"alert_afficher");
strcpy(ID,gtk_entry_get_text(GTK_ENTRY(id_supprimer)));


S=supprimer_election(ID);
if(S==1)
{
gtk_label_set_text(GTK_LABEL(alert_afficher),"Opération Réussie");
}
}


void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data)
{
char id[20];
char jou[20];
char moi[20];
char anne[20];
char nbr_bdv[20];

int a,b,c,z,W,f;
Election E;


GtkWidget *ide, *nbr_habitant, *municipalite,*nbr_conseillee,*adresse,*nom,*code_postal,*nbr_vote,*jour,*mois,*annee,*alert;
	GtkWidget *modifier_election;

	modifier_election=lookup_widget(objet,"modifier_election");
	
	ide=lookup_widget(objet,"id_modif");
	nbr_habitant=lookup_widget(objet,"nbr_habitant_modif");
	municipalite=lookup_widget(objet,"municipalite_modif");
	nbr_conseillee=lookup_widget(objet,"nbr_conseillee_modif");
	adresse=lookup_widget(objet,"adresse_modif");
	nom=lookup_widget(objet,"nom_modif");
	code_postal=lookup_widget(objet,"code_postal_modif");
	nbr_vote=lookup_widget(objet,"nbr_vote_modif");
	jour=lookup_widget(objet,"jour_modif");
	mois=lookup_widget(objet,"mois_modif");
	annee=lookup_widget(objet,"annee_modif");
	//alert=lookup_widget(objet,"alert");

	strcpy(E.id,gtk_entry_get_text(GTK_ENTRY(ide)));
	strcpy(E.nbr_habitant,gtk_entry_get_text(GTK_ENTRY(nbr_habitant)));
	strcpy(E.adresse,gtk_entry_get_text(GTK_ENTRY(adresse)));
	strcpy(E.nom,gtk_entry_get_text(GTK_ENTRY(nom)));
	strcpy(E.code_postal,gtk_entry_get_text(GTK_ENTRY(code_postal)));
	
	z=atoi(E.nbr_habitant);
	if(z<=5000)
	strcpy(E.nbr_conseillee,"10");
	if((z>=5001) && (z<=10000))
	strcpy(E.nbr_conseillee,"12");
	if((z>=10001) && (z<=25000))
	strcpy(E.nbr_conseillee,"16");
	if((z>=25001 && z<=50000))
	strcpy(E.nbr_conseillee,"22");
	if((z>=50001 && z<=100000))
	strcpy(E.nbr_conseillee,"30");
	if((z>=100001 && z<=500000))
	strcpy(E.nbr_conseillee,"40");
	if(z>500000)
	strcpy(E.nbr_conseillee,"60");
	 
	strcpy(E.municipalite,gtk_combo_box_get_active_text(GTK_COMBO_BOX(municipalite)));
	a=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(jour));
	sprintf(jou,"%d",a);
	b=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mois));
	sprintf(moi,"%d",b);
	c=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(annee));
	sprintf(anne,"%d",c);
	f=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(nbr_vote));
	sprintf(nbr_bdv,"%d",f);
	strcpy(E.d.jour,jou);
	strcpy(E.d.mois,moi);
	strcpy(E.d.annee,anne);
	strcpy(E.nbr_vote,nbr_bdv);
	strcpy(id,gtk_entry_get_text(GTK_ENTRY(ide)));
	//W=test_id(id);
	//if((confir[0]==1) && (W==1)){
	gtk_label_set_text(GTK_LABEL(nbr_conseillee),E.nbr_conseillee);
	modifier(id,E);
	//confir[0]=0;	
	//}
	//else 
	//{gtk_label_set_text(GTK_LABEL(alert),"Modification échoué");}


}





void
on_modifier_afficher_clicked           (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *afficher, *modifier_election;
afficher=lookup_widget(objet,"afficher");

gtk_widget_destroy(afficher);
modifier_election=create_modifier_election();
gtk_widget_show(modifier_election);
}


void
on_retour_modif_clicked                (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *afficher, *modifier_election,*treeview ;

modifier_election=lookup_widget(objet,"modifier_election");
gtk_widget_destroy(modifier_election);
afficher=create_afficher();
gtk_widget_show(afficher);


}


void
on_gestion_el_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *dashboard, *ajouter_election,*treeview ;

ajouter_election=lookup_widget(objet,"ajouter_election");
dashboard=lookup_widget(objet,"dashboard_admin");
gtk_widget_destroy(dashboard);
ajouter_election=create_ajouter_election();
gtk_widget_show(ajouter_election);
}


void
on_retour_ajouter_clicked              (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *dashboard, *ajouter_election,*treeview ;

ajouter_election=lookup_widget(objet,"ajouter_election");
dashboard=lookup_widget(objet,"dashboard_admin");
gtk_widget_destroy(ajouter_election);
dashboard=create_dashboard_admin();
gtk_widget_show(dashboard);
}


void
on_connection_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *dashboard, *ajouter_election,*treeview,*authentification,*passe,*compte ;
char ndc[20];
char mdp[20];
authentification=lookup_widget(objet,"authentification");
passe=lookup_widget(objet,"mdp");
compte=lookup_widget(objet,"ndc");
strcpy(ndc,gtk_entry_get_text(GTK_ENTRY(compte)));
strcpy(mdp,gtk_entry_get_text(GTK_ENTRY(passe)));
if ((strcmp(ndc,"admin")==0 && (strcmp(mdp,"admin")==0))){
	dashboard=lookup_widget(objet,"dashboard_admin");
	gtk_widget_destroy(authentification);
	dashboard=create_dashboard_admin();
	gtk_widget_show(dashboard);
}

}





void
on_deconnecter_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data)
{
GtkWidget *dashboard, *authentification ;

authentification=lookup_widget(objet,"authentification");
dashboard=lookup_widget(objet,"dashboard_admin");
gtk_widget_destroy(dashboard);
authentification=create_authentification();
gtk_widget_show(authentification);
}


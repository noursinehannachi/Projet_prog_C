#include <gtk/gtk.h>


void
on_ajouter_clicked                     (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);


void
on_afficher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_actualiser_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_clicked                      (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_chercher_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_confirmation_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_supprimer_election_clicked          (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);


void
on_modifier_clicked                    (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_modifier_afficher_clicked           (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_modif_clicked                (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_gestion_el_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_retour_ajouter_clicked              (GtkWidget       *objet,
                                        gpointer         user_data);

void
on_connection_clicked                  (GtkWidget       *objet,
                                        gpointer         user_data);



void
on_deconnecter_clicked                 (GtkWidget       *objet,
                                        gpointer         user_data);

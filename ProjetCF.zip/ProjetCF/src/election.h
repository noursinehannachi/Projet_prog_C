#include <gtk/gtk.h>
typedef struct{
	char jour[20];
	char mois[20];
	char annee[40];
}date;
typedef struct {

	char id[20];
	char nom[10];
	char nbr_habitant[10];
	char adresse[10];
	char code_postal[10];
	char municipalite[10];
	char nbr_vote[10];
	char nbr_conseillee[10];
	date d;
}Election;
void ajouter_election(Election p);
void afficher_election(GtkWidget *liste);
int modifier(char id[],Election nouv);
int supprimer_election(char id[20]);
Election chercher_election(char id[]);
Election afficher_chercher(GtkWidget *liste,char ID[]);
int id_rand();
